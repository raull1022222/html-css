function mudarTexto(){

    var x = document.querySelectorAll("p");


    x[0].innerHTML = "Aula de Programação para Web";
    x[1].style.fontSize = "40px";
    x[2].style.color = "Blue";
    x[3].style.textAlign = "Center";
    x[4].style.color = "Green";
    x[4].style.fontSize = "10px";
    x[5].innerHTML = "JavaScript não é Java";
    x[5].style.color = "Red";
    x[5].style.fontWeight = "bold";

}
function mudarPar(){
    var listaP = document.querySelectorAll("p");
    for(i =0 ; i < 6; i = i+2){
        listaP[i].style.backgroundColor = "yellow";
    }
}